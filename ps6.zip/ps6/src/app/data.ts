export class Weatherdata {
  name: string;
  weather:
    {
      description: string;
    }
  main: {
    humidity: number;
  }

}
