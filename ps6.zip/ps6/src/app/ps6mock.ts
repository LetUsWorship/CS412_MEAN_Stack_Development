import {Weatherdata} from './Weatherdata';

export const weatherdatas: Weatherdata[] =
  [
    {
      name: 'Boston',
      weather:
        {
          description: 'clear sky'
        },
      main: {
        humidity: 56,
      }
    },

    {
      name: 'Paris',
      weather:
        {
          description: 'cloudy'
        },
      main: {
        humidity: 67,
      }
    },

    {
      name: 'New York',
      weather:
        {
          description: 'clear sky'
        },
      main: {
        humidity: 31,
      }

    },

    {
      name: 'Shanghai',
      weather:
        {
          description: 'clear sky'
        },
      main: {
        humidity: 68,
      }
    },

    {
      name: 'Munich',
      weather:
        {
          description: 'clear sky'
        },
      main: {
        humidity: 93,
      }

    },

    {
      name: 'San Antonio',
      weather:
        {
          description: 'sunny'
        },
      main: {
        humidity: 20,
      }

    },

  ]
