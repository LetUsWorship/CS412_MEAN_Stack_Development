import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WeatherSpecificsComponent } from './weather-detail.component';

describe('WeatherDetailComponent', () => {
  let component: WeatherSpecificsComponent;
  let fixture: ComponentFixture<WeatherSpecificsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WeatherSpecificsComponent ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WeatherSpecificsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
