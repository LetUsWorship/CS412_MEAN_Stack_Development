export class Weather {
  name: string;
  weather: {
    description: string;
  };
  main: {
    humidity: string;
  };

}
